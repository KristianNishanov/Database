﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeAttendance.ViewModel
{
    public class RoleViewModel
    {
        [Required]
        public int Id { get; set; }

        [Required]
        [Display(Name = "Rolaname")]
        public string RoleName { get; set; }
    }
}
