﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeAttendance.ViewModel
{
    public class LoginViewModel
    {
        [Required]
        [Display(Name = "Login Email")]
        [EmailAddress]
        public string LoginEmail { get; set; }

        [Required]
        [Display(Name = "Password")]
        public string Password { get; set; }

    }
}
